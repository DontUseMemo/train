package exam01_field_polymorphism;

public class newHankookTire implements Tire {

    public void roll(){
        System.out.println("new! HankookTire run");
    }
}
