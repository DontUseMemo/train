package exam01_field_polymorphism;

public class KumhoTire implements Tire {
	@Override
	public void roll() {
		System.out.println(" ");
	}
}
