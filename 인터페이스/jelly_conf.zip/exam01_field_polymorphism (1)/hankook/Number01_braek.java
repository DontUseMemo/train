package hankook;

public class Number01_braek implements brake , Pedal {

    public void stop(){
        System.out.println("Number01 브레이크");
    }

    public void push(){
        System.out.println("Number01  패발 실행");
    }

}
