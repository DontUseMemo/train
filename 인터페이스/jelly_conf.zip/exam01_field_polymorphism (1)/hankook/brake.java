package hankook;

public interface brake {
    void stop();
}
