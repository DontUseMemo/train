package example_0706.dana;

public class Jellymain {
    public static void main(String[] args) {
        Human human = new Human();
        Human.HumanJelly();
    }
}
