package Question4;

public class main {
    public static void main(String[] args){
        JellyStore store = new JellyStore();
        store.action();
    }
}
