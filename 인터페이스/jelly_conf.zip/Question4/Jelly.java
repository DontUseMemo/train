package Question4;

public class Jelly {
    private String mango;
    private String grape;
    private String strawberry;

    public String getFlavor1() {
        return "mango";
    }

    public String getFlavor2() {
        return "grape";
    }

    public String getFlavor3() {
        return "strawberry";
    }
}
