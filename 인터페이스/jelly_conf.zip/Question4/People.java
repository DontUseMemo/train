package Question4;

public interface People  {

    abstract void Eat(String flavor);
    abstract void Pick(String flavor);
}
